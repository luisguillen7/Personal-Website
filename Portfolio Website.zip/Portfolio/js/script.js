/* Typing Animation */

var typed = new Typed(".typing", {
	strings:["", "Software Developer", "Web Designer", "Web Developer"],
	typeSpeed: 100,
	Backspeed: 30,
	loop: true
})