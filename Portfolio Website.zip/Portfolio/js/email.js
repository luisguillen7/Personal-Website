/* Send Email*/

const sendBtn = document.getElementById('sendEmail');

sendBtn.addEventListener('click', function(e) {
	e.preventDefault();
	const email = document.getElementById("email").value;
	const name = document.getElementById("name").value;
	const subject = document.getElementById("subject").value;
	const message = document.getElementById("message").value;
	window.location.href='mailto:lguil11@wgu.edu?
	subject=sentFromForm&body=Name%3A${name}%0AEmail%3A$
	{email}%0ASubject%3A${subject}%0AMessage%3A${message}';
});