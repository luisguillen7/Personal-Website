<?php

	$name = $_POST['name'];
	$email = $_POST['email'];
	$subject = $_POST['subject'];
	$message = $_POST['message'];
	
	$mailheader = "From:" .$name."<" .$email .">\r\n"
	
	$recipient = "lguil11@wgu.edu";
	
	mail($recipient. $subject .$message $.mailheader) or die("Error!");
	
	echo'
	<!DOCTYPE html>
	<html>
	<head>
		<title>Thank You</title>
	</head>
	<body>
		<h1> Thank you for contacting me.</h1>
	</body>
	</html>
	
	';
?>